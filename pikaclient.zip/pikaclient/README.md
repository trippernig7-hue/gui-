# PikaClient

A cosmetic / quality-of-life / performance client-side mod for Fabric on
Minecraft 1.21.1, in the spirit of clients like Feather - **without** the
features that give an unfair multiplayer advantage.

## What's intentionally NOT included

The original brief for this mod asked for reach modification, hitbox/tracer
ESP, fall-damage bypass, and a forced-fullbright toggle. Those were removed:
they're the standard toolkit of "hacked clients" and give an unfair edge
over other players in PvP/anti-cheat-protected servers. Everything below is
cosmetic, informational (HUD), or a pure rendering/performance setting -
none of it changes hit detection, movement physics, or visibility in a way
vanilla settings don't already allow.

The one visuals setting that might look similar to "fullbright" is the
**Brightness/Gamma slider** - that's a themed wrapper around vanilla's own
gamma option, which every player already has access to in normal video
settings.

## Features

- **Loading screen**: flat gray background, "PikaClient" wordmark, real
  progress bar tied to actual resource-reload progress, no Mojang branding.
- **Main menu**: gray tint, animated RGB accent strip, FPS/RAM readout,
  quick-access button into the PikaClient GUI.
- **Click GUI** (default: Right Shift): RGB-animated themed panel with six
  tabs - Gameplay, Visuals, HUD, Performance, Cosmetics, Settings.
- **Gameplay**: zoom (hold C, configurable FOV), sprint/sneak toggle mode,
  potion/armor status HUD toggles.
- **Visuals**: custom sky tint, clear water (fog push-back while
  submerged), better grass/leaves flag (config hook for resource-pack-style
  tweaks), brightness/gamma slider, custom time-of-day, entity culling,
  dynamic lights flag, RGB accent color picker, custom crosshair + color.
- **HUD**: FPS, ping, CPS (real click-timestamp based), keystrokes (RGB
  animated), coordinates, direction, server IP, memory usage, armor/potion
  status, compass strip, waypoints (via `/pika waypoint add <name>`),
  simplified radar-style minimap, HUD presets, scale/opacity sliders, and
  ALT+drag repositioning for every element.
- **Performance**: render/entity distance dropdowns, FPS cap, dynamic FPS
  (throttles when unfocused), fast render/math flags, chunk caching flag,
  threaded rendering flag, particle limit (actively enforced), entity/tile
  culling, antialiasing + anisotropic filtering dropdowns, "Optimize Now"
  one-click preset.
- **Cosmetics**: cape (4 styles), wings (4 styles), halo, glow aura, animated
  nametag flag, pet marker, particle trail (4 types), all configurable with
  live color pickers.
- **Settings**: GUI opacity, RGB animation speed, primary/secondary colors,
  theme selector, compact mode, export/import config to JSON, reset to
  defaults.

## Known simplifications (being upfront about scope)

- **Cosmetics are client-side only.** There's no backend service syncing
  who's wearing what to other players, so capes/wings/etc. render in your
  own game (visible in F5 third-person, screenshots, etc.) but not to
  other players unless they also run PikaClient pointed at a shared
  service - which is out of scope for a single client-side mod.
- **Minimap** is a simplified radar (shows nearby players as dots relative
  to your facing) rather than a full rendered-terrain minimap, which would
  require an off-screen chunk-rendering pipeline.
- **Fast Math / Chunk Caching / Threaded Rendering** toggles exist as real
  config flags read by other systems (and are honest about what they do in
  code comments), but a handful of the deepest render-pipeline
  optimizations (the kind Sodium does at the chunk-mesh level) require
  replacing Minecraft's chunk renderer entirely - that's a multi-month
  project on its own, not something to bolt onto a cosmetics mod. The
  particle limit, entity distance culling, and FPS cap ARE actively
  enforced.

## Building

Requires JDK 21.

```bash
./gradlew build
```

The build output will be in `build/libs/`. Drop the non-`-sources.jar` file
into your `mods` folder alongside Fabric API 0.102.0+ for 1.21.1.

> Note: this repo includes the Gradle build scripts but not the binary
> `gradle-wrapper.jar` (binary files aren't practical to hand-author). If
> `./gradlew` doesn't work out of the box, run `gradle wrapper --gradle-version 8.8`
> once with a local Gradle install to generate it, or open the project
> directly in an IDE with the Fabric/Loom plugin.

## Requirements

- Minecraft 1.21.1
- Fabric Loader 0.16.9+
- Fabric API 0.102.0+1.21.1
- Java 21

## Keybinds

| Key | Action |
|---|---|
| Right Shift | Open PikaClient GUI |
| C | Zoom (hold) |
| R | Toggle sprint |
| ALT + drag | Reposition a HUD element |

## Config

Settings are stored at `config/pikaclient.json` and can be exported/imported
from the Settings tab (exports land in your Minecraft run directory as
`pikaclient_export_<timestamp>.json`).
