package com.pika.client.config;

import java.util.HashMap;
import java.util.Map;

/**
 * Plain-data holder for every configurable value in PikaClient.
 * Serialized to/from JSON by {@link ConfigManager}. Nothing in here
 * grants a gameplay advantage - it's toggles for HUD, visuals,
 * performance and cosmetics only.
 */
public class ModConfig {

    // ---------- Gameplay (fair-play only) ----------
    public boolean zoomEnabled = true;
    public double zoomFov = 30.0;          // FOV while holding the zoom key
    public boolean sprintToggle = false;   // toggle instead of hold-to-sprint
    public boolean sneakToggle = false;    // toggle instead of hold-to-sneak
    public boolean potionStatusHud = true;
    public boolean armorStatusHud = true;

    // ---------- Visuals ----------
    public boolean customSky = true;
    public boolean clearWater = false;
    public boolean betterGrassLeaves = true;
    public double brightness = 1.0;        // maps directly to vanilla gamma option (0-1 vanilla range, we allow up to 1)
    public boolean customTimeEnabled = false;
    public long customTime = 6000;
    public boolean entityCulling = true;
    public boolean dynamicLights = true;
    public int accentColorRGB = 0x7B5CFF;
    public boolean customCrosshair = false;
    public int crosshairColorRGB = 0xFFFFFF;

    // ---------- HUD ----------
    public boolean hudFps = true;
    public boolean hudPing = true;
    public boolean hudCps = true;
    public boolean hudKeystrokes = true;
    public boolean hudKeystrokesRgb = true;
    public boolean hudCoords = true;
    public boolean hudDirection = true;
    public boolean hudServerIp = false;
    public boolean hudMemory = true;
    public boolean hudCompass = true;
    public boolean hudWaypoints = true;
    public boolean hudMinimap = true;
    public float hudScale = 1.0f;
    public float hudOpacity = 1.0f;
    public String hudPreset = "default";
    public Map<String, int[]> hudPositions = new HashMap<>(); // elementId -> [x, y]

    // ---------- Performance ----------
    public int renderDistance = 12;
    public int entityDistance = 100; // percent, matches vanilla slider
    public int fpsCap = 260;         // 0 = unlimited
    public boolean dynamicFps = true;
    public boolean fastRender = true;
    public boolean fastMath = true;
    public boolean chunkCaching = true;
    public boolean threadedRendering = true;
    public int particleLimit = 4000;
    public boolean entityCullingPerf = true;
    public boolean tileCulling = true;
    public int antialiasing = 0; // 0,2,4,8
    public int anisotropicFiltering = 1; // 1,2,4,8,16

    // ---------- Cosmetics (client-side visible to yourself; see README) ----------
    public boolean capeEnabled = false;
    public String capeStyle = "classic";
    public boolean wingsEnabled = false;
    public String wingStyle = "angel";
    public boolean haloEnabled = false;
    public boolean glowEnabled = false;
    public int glowColorRGB = 0x00FFFF;
    public boolean animatedNametag = false;
    public boolean petEnabled = false;
    public String petType = "none";
    public boolean particleTrail = false;
    public String particleTrailType = "flame";

    // ---------- Settings ----------
    public float guiOpacity = 0.85f;
    public float rgbSpeed = 1.0f;
    public int primaryColorRGB = 0x7B5CFF;
    public int secondaryColorRGB = 0x00D4FF;
    public String theme = "gray"; // gray, dark, light
    public boolean compactMode = false;
}
