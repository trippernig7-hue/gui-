package com.pika.client.hud;

import java.util.ArrayList;
import java.util.List;

/**
 * Minimal in-memory waypoint store. Waypoints are set via chat command
 * (see below) or could be wired into a future "add waypoint" GUI button.
 */
public final class WaypointManager {

    public record Waypoint(String name, double x, double y, double z) {}

    private static final List<Waypoint> WAYPOINTS = new ArrayList<>();
    private static Waypoint active;

    private WaypointManager() {}

    public static void add(Waypoint waypoint) {
        WAYPOINTS.add(waypoint);
        if (active == null) active = waypoint;
    }

    public static List<Waypoint> all() {
        return WAYPOINTS;
    }

    public static Waypoint getActive() {
        return active;
    }

    public static void setActive(Waypoint waypoint) {
        active = waypoint;
    }

    public static void clear() {
        WAYPOINTS.clear();
        active = null;
    }
}
