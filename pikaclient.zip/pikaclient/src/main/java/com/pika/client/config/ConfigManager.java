package com.pika.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Handles reading/writing the mod config to disk, plus export/import
 * to an arbitrary path so users can back up or share settings.
 */
public final class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("pikaclient.json");

    private static ModConfig config;

    private ConfigManager() {}

    public static ModConfig get() {
        if (config == null) {
            config = load();
        }
        return config;
    }

    public static ModConfig load() {
        try {
            if (Files.exists(CONFIG_PATH)) {
                String json = Files.readString(CONFIG_PATH);
                ModConfig loaded = GSON.fromJson(json, ModConfig.class);
                if (loaded != null) {
                    return loaded;
                }
            }
        } catch (IOException | com.google.gson.JsonSyntaxException e) {
            System.err.println("[PikaClient] Failed to load config, using defaults: " + e.getMessage());
        }
        return new ModConfig();
    }

    public static void save() {
        if (config == null) return;
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(config));
        } catch (IOException e) {
            System.err.println("[PikaClient] Failed to save config: " + e.getMessage());
        }
    }

    /** Exports the current config to an arbitrary destination file. */
    public static boolean exportTo(Path destination) {
        try {
            Files.createDirectories(destination.getParent());
            Files.writeString(destination, GSON.toJson(get()));
            return true;
        } catch (IOException e) {
            System.err.println("[PikaClient] Export failed: " + e.getMessage());
            return false;
        }
    }

    /** Imports a config from an arbitrary source file, replacing the current one. */
    public static boolean importFrom(Path source) {
        try {
            String json = Files.readString(source);
            ModConfig imported = GSON.fromJson(json, ModConfig.class);
            if (imported != null) {
                config = imported;
                save();
                return true;
            }
        } catch (IOException | com.google.gson.JsonSyntaxException e) {
            System.err.println("[PikaClient] Import failed: " + e.getMessage());
        }
        return false;
    }

    public static void resetToDefaults() {
        config = new ModConfig();
        save();
    }
}
