package com.pika.client.gui.widget;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Non-interactive wrapped hint text, used for short tips inside a tab panel. */
public class LabelWidget extends PikaWidget {

    public LabelWidget(String text, int panelWidth) {
        super(text, panelWidth, 24);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, int accentColor) {
        var tr = MinecraftClient.getInstance().textRenderer;
        java.util.List<net.minecraft.text.OrderedText> lines =
                tr.wrapLines(net.minecraft.text.Text.of(label), width - 8);
        int lineY = y + 2;
        for (net.minecraft.text.OrderedText line : lines) {
            ctx.drawTextWithShadow(tr, line, x + 4, lineY, 0xFF9A9A9A);
            lineY += tr.fontHeight + 1;
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return false;
    }
}
