package com.pika.client.mixin;

import com.pika.client.PikaClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Sprint/Sneak "toggle" convenience: instead of holding the sprint or
 * sneak key, the player flips a persistent flag once. This does not
 * change movement speed, hunger cost, or any other mechanic - it only
 * changes how the existing vanilla state is triggered, exactly like a
 * "toggle sprint" accessibility option.
 */
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void pikaclient$applyToggles(CallbackInfo ci) {
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;

        if (PikaClient.config.sprintToggle) {
            boolean movingForward = self.input.movementForward > 0.0f;
            boolean blocked = self.isSneaking() || self.getHungerManager().getFoodLevel() <= 6 && !self.getAbilities().creativeMode;
            if (movingForward && !blocked) {
                self.setSprinting(true);
            }
        }

        if (PikaClient.config.sneakToggle) {
            self.setSneaking(true);
        }
    }
}
