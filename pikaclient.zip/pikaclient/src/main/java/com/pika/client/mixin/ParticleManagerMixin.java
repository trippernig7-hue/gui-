package com.pika.client.mixin;

import com.pika.client.util.PerformanceManager;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Enforces the Performance tab's particle-limit slider by rejecting new
 * particles once the per-tick budget (derived from the configured limit)
 * is exhausted. This is a pure performance feature - it never touches
 * gameplay-relevant particles selectively, it simply throttles volume.
 */
@Mixin(ParticleManager.class)
public class ParticleManagerMixin {

    @Inject(method = "addParticle(Lnet/minecraft/client/particle/Particle;)V", at = @At("HEAD"), cancellable = true)
    private void pikaclient$enforceParticleLimit(Particle particle, CallbackInfo ci) {
        if (!PerformanceManager.tryConsumeParticleBudget()) {
            ci.cancel();
        }
    }
}
