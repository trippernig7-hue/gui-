package com.pika.client.util;

import com.mojang.blaze3d.systems.RenderSystem;
import com.pika.client.config.ConfigManager;
import com.pika.client.config.ModConfig;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Implements the Visuals tab's "Clear Water" and "Custom Sky" features
 * using {@link WorldRenderEvents}, Fabric API's stable, documented
 * client-rendering event bus - deliberately avoiding raw mixins into
 * WorldRenderer/BackgroundRenderer internals, which change shape often
 * between Minecraft versions.
 */
public final class VisualsManager {

    private VisualsManager() {}

    public static void init() {
        WorldRenderEvents.START.register(VisualsManager::onRenderStart);
        WorldRenderEvents.SKY.register(VisualsManager::onRenderSky);
    }

    /** Clear Water: widen/soften the underwater fog so visibility reads as much clearer. */
    private static void onRenderStart(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        ModConfig c = ConfigManager.get();
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        if (c.clearWater && client.player.isSubmergedInWater()) {
            RenderSystem.setShaderFogStart(0f);
            RenderSystem.setShaderFogEnd(64f);
        }
    }

    /**
     * Custom Sky: draws a soft, accent-colored gradient band near the
     * horizon on top of vanilla's sky (which still renders sun/moon/stars
     * normally). Kept as a subtle tint rather than replacing the sky
     * entirely, so it reads as a theme rather than breaking immersion.
     */
    private static void onRenderSky(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context) {
        ModConfig c = ConfigManager.get();
        if (!c.customSky) return;

        MatrixStack matrices = context.matrixStack();
        if (matrices == null) return;

        int color = RGBUtil.withAlpha(c.accentColorRGB, 40); // subtle
        float a = ((color >> 24) & 0xFF) / 255f;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.depthMask(false);

        matrices.push();
        var mat = matrices.peek().getPositionMatrix();
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        float radius = 100f;
        buffer.vertex(mat, 0, 12f, 0).color(r, g, b, a);
        int segments = 16;
        for (int i = 0; i <= segments; i++) {
            double angle = (i / (double) segments) * Math.PI * 2;
            float x = (float) (Math.cos(angle) * radius);
            float z = (float) (Math.sin(angle) * radius);
            buffer.vertex(mat, x, 8f, z).color(r, g, b, 0f);
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        matrices.pop();

        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
    }
}
