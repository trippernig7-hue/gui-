package com.pika.client.gui.widget;

import net.minecraft.client.gui.DrawContext;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** A click-to-cycle dropdown (click cycles to the next option; simple and touch-friendly). */
public class DropdownWidget extends PikaWidget {

    private final List<String> options;
    private final Supplier<Integer> indexGetter;
    private final Consumer<Integer> indexSetter;

    public DropdownWidget(String label, int panelWidth, List<String> options,
                           Supplier<Integer> indexGetter, Consumer<Integer> indexSetter) {
        super(label, panelWidth, 22);
        this.options = options;
        this.indexGetter = indexGetter;
        this.indexSetter = indexSetter;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, int accentColor) {
        var tr = net.minecraft.client.MinecraftClient.getInstance().textRenderer;
        boolean hovered = isHovered(mouseX, mouseY);
        ctx.drawTextWithShadow(tr, label, x + 4, y + 6, 0xFFEAEAEA);

        int idx = indexGetter.get();
        String value = options.isEmpty() ? "" : options.get(Math.floorMod(idx, options.size()));
        int boxW = 90, boxH = 16;
        int bx = x + width - boxW - 4, by = y + 3;
        ctx.fill(bx, by, bx + boxW, by + boxH, hovered ? 0x33FFFFFF : 0x22000000);
        ctx.drawBorder(bx, by, boxW, boxH, accentColor);
        ctx.drawTextWithShadow(tr, value + " \u25BE", bx + 5, by + 4, 0xFFEAEAEA);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && isHovered(mouseX, mouseY) && !options.isEmpty()) {
            int idx = indexGetter.get();
            indexSetter.accept(Math.floorMod(idx + 1, options.size()));
            return true;
        }
        return false;
    }
}
