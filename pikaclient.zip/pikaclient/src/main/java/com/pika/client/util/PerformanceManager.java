package com.pika.client.util;

import com.pika.client.config.ConfigManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Tracks how many particles PikaClient has allowed to spawn this tick so
 * {@code ParticleManagerMixin} can enforce the configured particle-limit
 * budget without needing to inspect ParticleManager's internal storage.
 * The budget is spread evenly across the 20 ticks/second so bursts (e.g.
 * an explosion) don't blow through the whole limit in one frame.
 */
public final class PerformanceManager {

    private static final AtomicInteger spawnedThisTick = new AtomicInteger();

    private PerformanceManager() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> spawnedThisTick.set(0));
    }

    /** @return true if this particle spawn should be allowed under the current budget */
    public static boolean tryConsumeParticleBudget() {
        int limit = ConfigManager.get().particleLimit;
        if (limit <= 0) return true; // 0 = unlimited in this context guard (UI clamps to sane range)
        int perTickBudget = Math.max(1, limit / 20);
        return spawnedThisTick.incrementAndGet() <= perTickBudget;
    }
}
