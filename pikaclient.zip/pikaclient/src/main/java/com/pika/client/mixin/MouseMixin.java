package com.pika.client.mixin;

import com.pika.client.hud.HudManager;
import com.pika.client.util.InputTracker;
import net.minecraft.client.Mouse;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks raw mouse input for two purposes:
 * 1. Accurate CPS (clicks-per-second) tracking via real click timestamps
 *    rather than tick-sampled key state, which would undercount fast clicks.
 * 2. ALT+drag repositioning of HUD elements while no screen is open (in
 *    the HUD tab you can also just open the GUI, but ALT+drag lets you
 *    reposition without leaving gameplay).
 */
@Mixin(Mouse.class)
public class MouseMixin {

    @Shadow private double x;
    @Shadow private double y;

    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void pikaclient$onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean altHeld = (mods & GLFW.GLFW_MOD_ALT) != 0;

        if (action == GLFW.GLFW_PRESS) {
            if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
                InputTracker.onLeftClick();
                InputTracker.leftMouseDown = true;
            } else if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
                InputTracker.onRightClick();
                InputTracker.rightMouseDown = true;
            }

            if (altHeld && client.currentScreen == null && button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
                double scale = client.getWindow().getScaleFactor();
                HudManager.tryStartDrag(x / scale, y / scale);
            }
        } else if (action == GLFW.GLFW_RELEASE) {
            if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) InputTracker.leftMouseDown = false;
            if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) InputTracker.rightMouseDown = false;
            if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
                HudManager.stopDrag();
            }
        }
    }

    @Inject(method = "onCursorPos", at = @At("HEAD"))
    private void pikaclient$onCursorPos(long window, double x, double y, CallbackInfo ci) {
        if (HudManager.isDragging()) {
            MinecraftClient client = MinecraftClient.getInstance();
            double scale = client.getWindow().getScaleFactor();
            HudManager.updateDrag(x / scale, y / scale);
        }
    }
}
