package com.pika.client.mixin;

import com.pika.client.PikaClient;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies the Performance tab's FPS cap and "reduce FPS when unfocused"
 * (dynamic FPS) settings by driving Minecraft's own built-in options,
 * rather than reimplementing a frame limiter. This keeps behavior
 * consistent with vanilla's tested render-loop timing.
 */
@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {

    private int pikaclient$lastAppliedCap = -1;

    @Inject(method = "render", at = @At("HEAD"))
    private void pikaclient$syncPerformanceOptions(boolean tick, CallbackInfo ci) {
        MinecraftClient client = (MinecraftClient) (Object) this;

        // Dynamic FPS: when the window loses focus, clamp much lower than the
        // configured cap to save power/CPU, matching what "Dynamic FPS" mods do.
        int desiredCap = PikaClient.config.fpsCap == 0 ? 260 : PikaClient.config.fpsCap;
        if (PikaClient.config.dynamicFps && !client.isWindowFocused()) {
            desiredCap = Math.min(desiredCap, 15);
        }

        if (desiredCap != pikaclient$lastAppliedCap) {
            client.options.getMaxFps().setValue(desiredCap);
            pikaclient$lastAppliedCap = desiredCap;
        }
    }
}
