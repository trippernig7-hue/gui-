package com.pika.client.gui;

import com.pika.client.config.ConfigManager;
import com.pika.client.config.ModConfig;
import com.pika.client.gui.widget.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ConfirmScreen;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Builds the widget list for each tab. Kept as static factory methods so
 * ClickGuiScreen can rebuild a tab's widgets cheaply when it's selected.
 * Every widget here reads/writes {@link ModConfig} directly, so changes
 * apply live with no "Apply" button needed.
 */
public final class GuiTabs {

    public enum Tab {
        GAMEPLAY("Gameplay"),
        VISUALS("Visuals"),
        HUD("HUD"),
        PERFORMANCE("Performance"),
        COSMETICS("Cosmetics"),
        SETTINGS("Settings");

        public final String displayName;
        Tab(String displayName) { this.displayName = displayName; }
    }

    private GuiTabs() {}

    public static List<PikaWidget> build(Tab tab, int panelWidth) {
        ModConfig c = ConfigManager.get();
        List<PikaWidget> widgets = new ArrayList<>();

        switch (tab) {
            case GAMEPLAY -> {
                widgets.add(new ToggleWidget("Zoom (hold C)", panelWidth, () -> c.zoomEnabled, v -> c.zoomEnabled = v));
                widgets.add(new SliderWidget("Zoom FOV", panelWidth, 5, 60,
                        () -> c.zoomFov, v -> c.zoomFov = v, v -> String.format("%.0f\u00B0", v)));
                widgets.add(new ToggleWidget("Sprint Toggle (R)", panelWidth, () -> c.sprintToggle, v -> c.sprintToggle = v));
                widgets.add(new ToggleWidget("Sneak Toggle", panelWidth, () -> c.sneakToggle, v -> c.sneakToggle = v));
                widgets.add(new ToggleWidget("Potion Status HUD", panelWidth, () -> c.potionStatusHud, v -> c.potionStatusHud = v));
                widgets.add(new ToggleWidget("Armor Status HUD", panelWidth, () -> c.armorStatusHud, v -> c.armorStatusHud = v));
            }
            case VISUALS -> {
                widgets.add(new ToggleWidget("Custom Sky", panelWidth, () -> c.customSky, v -> c.customSky = v));
                widgets.add(new ToggleWidget("Clear Water", panelWidth, () -> c.clearWater, v -> c.clearWater = v));
                widgets.add(new ToggleWidget("Better Grass/Leaves", panelWidth, () -> c.betterGrassLeaves, v -> c.betterGrassLeaves = v));
                widgets.add(new SliderWidget("Brightness / Gamma", panelWidth, 0.0, 1.0,
                        () -> c.brightness, v -> c.brightness = v, v -> String.format("%.0f%%", v * 100)));
                widgets.add(new ToggleWidget("Custom Time of Day", panelWidth, () -> c.customTimeEnabled, v -> c.customTimeEnabled = v));
                widgets.add(new SliderWidget("Time", panelWidth, 0, 24000,
                        () -> c.customTime, v -> c.customTime = (long) v, v -> String.format("%.0f ticks", v)));
                widgets.add(new ToggleWidget("Entity Culling", panelWidth, () -> c.entityCulling, v -> c.entityCulling = v));
                widgets.add(new ToggleWidget("Dynamic Lights", panelWidth, () -> c.dynamicLights, v -> c.dynamicLights = v));
                widgets.add(new ColorPickerWidget("Accent Color", panelWidth, () -> c.accentColorRGB, v -> c.accentColorRGB = v));
                widgets.add(new ToggleWidget("Custom Crosshair", panelWidth, () -> c.customCrosshair, v -> c.customCrosshair = v));
                widgets.add(new ColorPickerWidget("Crosshair Color", panelWidth, () -> c.crosshairColorRGB, v -> c.crosshairColorRGB = v));
            }
            case HUD -> {
                widgets.add(new ToggleWidget("FPS", panelWidth, () -> c.hudFps, v -> c.hudFps = v));
                widgets.add(new ToggleWidget("Ping", panelWidth, () -> c.hudPing, v -> c.hudPing = v));
                widgets.add(new ToggleWidget("CPS", panelWidth, () -> c.hudCps, v -> c.hudCps = v));
                widgets.add(new ToggleWidget("Keystrokes", panelWidth, () -> c.hudKeystrokes, v -> c.hudKeystrokes = v));
                widgets.add(new ToggleWidget("Keystrokes RGB", panelWidth, () -> c.hudKeystrokesRgb, v -> c.hudKeystrokesRgb = v));
                widgets.add(new ToggleWidget("Coordinates", panelWidth, () -> c.hudCoords, v -> c.hudCoords = v));
                widgets.add(new ToggleWidget("Direction", panelWidth, () -> c.hudDirection, v -> c.hudDirection = v));
                widgets.add(new ToggleWidget("Server IP", panelWidth, () -> c.hudServerIp, v -> c.hudServerIp = v));
                widgets.add(new ToggleWidget("Memory Usage", panelWidth, () -> c.hudMemory, v -> c.hudMemory = v));
                widgets.add(new ToggleWidget("Compass", panelWidth, () -> c.hudCompass, v -> c.hudCompass = v));
                widgets.add(new ToggleWidget("Waypoints", panelWidth, () -> c.hudWaypoints, v -> c.hudWaypoints = v));
                widgets.add(new ToggleWidget("Minimap", panelWidth, () -> c.hudMinimap, v -> c.hudMinimap = v));
                widgets.add(new DropdownWidget("HUD Preset", panelWidth,
                        List.of("default", "compact", "minimal", "full"),
                        () -> List.of("default", "compact", "minimal", "full").indexOf(c.hudPreset),
                        i -> c.hudPreset = List.of("default", "compact", "minimal", "full").get(i)));
                widgets.add(new SliderWidget("HUD Scale", panelWidth, 0.5, 2.0,
                        () -> c.hudScale, v -> c.hudScale = (float) v, v -> String.format("%.1fx", v)));
                widgets.add(new SliderWidget("HUD Opacity", panelWidth, 0.1, 1.0,
                        () -> c.hudOpacity, v -> c.hudOpacity = (float) v, v -> String.format("%.0f%%", v * 100)));
                widgets.add(new LabelWidget("Hold ALT and drag any HUD element to reposition it.", panelWidth));
            }
            case PERFORMANCE -> {
                widgets.add(new DropdownWidget("Render Distance", panelWidth,
                        List.of("4", "8", "12", "16", "24", "32"),
                        () -> distIndex(c.renderDistance), i -> c.renderDistance = Integer.parseInt(
                                List.of("4", "8", "12", "16", "24", "32").get(i))));
                widgets.add(new DropdownWidget("Entity Distance", panelWidth,
                        List.of("50%", "75%", "100%", "150%", "200%"),
                        () -> entDistIndex(c.entityDistance), i -> c.entityDistance = Integer.parseInt(
                                List.of("50%", "75%", "100%", "150%", "200%").get(i).replace("%", ""))));
                widgets.add(new SliderWidget("FPS Cap (0=unlimited)", panelWidth, 0, 400,
                        () -> c.fpsCap, v -> c.fpsCap = (int) v, v -> v == 0 ? "Unlimited" : String.format("%.0f", v)));
                widgets.add(new ToggleWidget("Dynamic FPS", panelWidth, () -> c.dynamicFps, v -> c.dynamicFps = v));
                widgets.add(new ToggleWidget("Fast Render", panelWidth, () -> c.fastRender, v -> c.fastRender = v));
                widgets.add(new ToggleWidget("Fast Math", panelWidth, () -> c.fastMath, v -> c.fastMath = v));
                widgets.add(new ToggleWidget("Chunk Caching", panelWidth, () -> c.chunkCaching, v -> c.chunkCaching = v));
                widgets.add(new ToggleWidget("Threaded Rendering", panelWidth, () -> c.threadedRendering, v -> c.threadedRendering = v));
                widgets.add(new SliderWidget("Particle Limit", panelWidth, 0, 16000,
                        () -> c.particleLimit, v -> c.particleLimit = (int) v, v -> String.format("%.0f", v)));
                widgets.add(new ToggleWidget("Entity Culling", panelWidth, () -> c.entityCullingPerf, v -> c.entityCullingPerf = v));
                widgets.add(new ToggleWidget("Tile Entity Culling", panelWidth, () -> c.tileCulling, v -> c.tileCulling = v));
                widgets.add(new DropdownWidget("Antialiasing", panelWidth,
                        List.of("Off", "2x", "4x", "8x"),
                        () -> aaIndex(c.antialiasing), i -> c.antialiasing = new int[]{0, 2, 4, 8}[i]));
                widgets.add(new DropdownWidget("Anisotropic Filtering", panelWidth,
                        List.of("1x", "2x", "4x", "8x", "16x"),
                        () -> afIndex(c.anisotropicFiltering), i -> c.anisotropicFiltering = new int[]{1, 2, 4, 8, 16}[i]));
                widgets.add(new ActionButtonWidget("Optimize Now", panelWidth, GuiTabs::optimizeNow));
            }
            case COSMETICS -> {
                widgets.add(new ToggleWidget("Cape", panelWidth, () -> c.capeEnabled, v -> c.capeEnabled = v));
                widgets.add(new DropdownWidget("Cape Style", panelWidth,
                        List.of("classic", "wave", "tattered", "royal"),
                        () -> List.of("classic", "wave", "tattered", "royal").indexOf(c.capeStyle),
                        i -> c.capeStyle = List.of("classic", "wave", "tattered", "royal").get(i)));
                widgets.add(new ToggleWidget("Wings", panelWidth, () -> c.wingsEnabled, v -> c.wingsEnabled = v));
                widgets.add(new DropdownWidget("Wing Style", panelWidth,
                        List.of("angel", "demon", "dragon", "fairy"),
                        () -> List.of("angel", "demon", "dragon", "fairy").indexOf(c.wingStyle),
                        i -> c.wingStyle = List.of("angel", "demon", "dragon", "fairy").get(i)));
                widgets.add(new ToggleWidget("Halo", panelWidth, () -> c.haloEnabled, v -> c.haloEnabled = v));
                widgets.add(new ToggleWidget("Glow Effect", panelWidth, () -> c.glowEnabled, v -> c.glowEnabled = v));
                widgets.add(new ColorPickerWidget("Glow Color", panelWidth, () -> c.glowColorRGB, v -> c.glowColorRGB = v));
                widgets.add(new ToggleWidget("Animated Nametag", panelWidth, () -> c.animatedNametag, v -> c.animatedNametag = v));
                widgets.add(new ToggleWidget("Pet", panelWidth, () -> c.petEnabled, v -> c.petEnabled = v));
                widgets.add(new DropdownWidget("Pet Type", panelWidth,
                        List.of("none", "cat", "dragon", "chicken"),
                        () -> List.of("none", "cat", "dragon", "chicken").indexOf(c.petType),
                        i -> c.petType = List.of("none", "cat", "dragon", "chicken").get(i)));
                widgets.add(new ToggleWidget("Particle Trail", panelWidth, () -> c.particleTrail, v -> c.particleTrail = v));
                widgets.add(new DropdownWidget("Trail Type", panelWidth,
                        List.of("flame", "heart", "sparkle", "smoke"),
                        () -> List.of("flame", "heart", "sparkle", "smoke").indexOf(c.particleTrailType),
                        i -> c.particleTrailType = List.of("flame", "heart", "sparkle", "smoke").get(i)));
                widgets.add(new LabelWidget("Cosmetics render locally (self-view/screenshots).", panelWidth));
            }
            case SETTINGS -> {
                widgets.add(new SliderWidget("GUI Opacity", panelWidth, 0.2, 1.0,
                        () -> c.guiOpacity, v -> c.guiOpacity = (float) v, v -> String.format("%.0f%%", v * 100)));
                widgets.add(new SliderWidget("RGB Speed", panelWidth, 0.1, 3.0,
                        () -> c.rgbSpeed, v -> c.rgbSpeed = (float) v, v -> String.format("%.1fx", v)));
                widgets.add(new ColorPickerWidget("Primary Color", panelWidth, () -> c.primaryColorRGB, v -> c.primaryColorRGB = v));
                widgets.add(new ColorPickerWidget("Secondary Color", panelWidth, () -> c.secondaryColorRGB, v -> c.secondaryColorRGB = v));
                widgets.add(new DropdownWidget("Theme", panelWidth,
                        List.of("gray", "dark", "light"),
                        () -> List.of("gray", "dark", "light").indexOf(c.theme),
                        i -> c.theme = List.of("gray", "dark", "light").get(i)));
                widgets.add(new ToggleWidget("Compact Mode", panelWidth, () -> c.compactMode, v -> c.compactMode = v));
                widgets.add(new ActionButtonWidget("Export Settings", panelWidth, GuiTabs::exportSettings));
                widgets.add(new ActionButtonWidget("Import Settings", panelWidth, GuiTabs::importSettings));
                widgets.add(new ActionButtonWidget("Reset to Defaults", panelWidth, GuiTabs::confirmReset));
            }
        }
        return widgets;
    }

    private static int distIndex(int val) {
        int[] opts = {4, 8, 12, 16, 24, 32};
        for (int i = 0; i < opts.length; i++) if (opts[i] == val) return i;
        return 2;
    }

    private static int entDistIndex(int val) {
        int[] opts = {50, 75, 100, 150, 200};
        for (int i = 0; i < opts.length; i++) if (opts[i] == val) return i;
        return 2;
    }

    private static int aaIndex(int val) {
        int[] opts = {0, 2, 4, 8};
        for (int i = 0; i < opts.length; i++) if (opts[i] == val) return i;
        return 0;
    }

    private static int afIndex(int val) {
        int[] opts = {1, 2, 4, 8, 16};
        for (int i = 0; i < opts.length; i++) if (opts[i] == val) return i;
        return 0;
    }

    /** Applies an aggressive-but-fair preset to the performance tab in one click. */
    private static void optimizeNow() {
        ModConfig c = ConfigManager.get();
        c.renderDistance = 8;
        c.entityDistance = 75;
        c.fastRender = true;
        c.fastMath = true;
        c.chunkCaching = true;
        c.threadedRendering = true;
        c.particleLimit = 1000;
        c.entityCullingPerf = true;
        c.tileCulling = true;
        c.antialiasing = 0;
        c.anisotropicFiltering = 1;
        c.dynamicFps = true;
        ConfigManager.save();
    }

    private static void exportSettings() {
        Path dest = MinecraftClient.getInstance().runDirectory.toPath()
                .resolve("pikaclient_export_" + System.currentTimeMillis() + ".json");
        boolean ok = ConfigManager.exportTo(dest);
        System.out.println("[PikaClient] Export " + (ok ? "succeeded: " + dest : "failed"));
    }

    private static void importSettings() {
        // Looks for the most recent export in the run directory; a full file-picker
        // would need AWT/Swing which we intentionally avoid pulling into a game process.
        Path dir = MinecraftClient.getInstance().runDirectory.toPath();
        try (var stream = java.nio.file.Files.list(dir)) {
            stream.filter(p -> p.getFileName().toString().startsWith("pikaclient_export_"))
                    .max(java.util.Comparator.comparing(p -> p.toFile().lastModified()))
                    .ifPresentOrElse(
                            p -> System.out.println("[PikaClient] Import " + (ConfigManager.importFrom(p) ? "succeeded from " + p : "failed")),
                            () -> System.out.println("[PikaClient] No export file found to import.")
                    );
        } catch (Exception e) {
            System.err.println("[PikaClient] Import scan failed: " + e.getMessage());
        }
    }

    private static void confirmReset() {
        MinecraftClient client = MinecraftClient.getInstance();
        client.setScreen(new ConfirmScreen(confirmed -> {
            if (confirmed) {
                ConfigManager.resetToDefaults();
            }
            client.setScreen(new com.pika.client.gui.ClickGuiScreen());
        }, net.minecraft.text.Text.of("Reset PikaClient settings?"),
           net.minecraft.text.Text.of("This will restore all defaults. This cannot be undone.")));
    }
}
