package com.pika.client.mixin;

import com.pika.client.util.RGBUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.resource.ResourceReload;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reskins the resource-reload loading screen: a flat gray backdrop,
 * "PikaClient" wordmark, and a progress bar driven by the actual
 * {@link ResourceReload} progress.
 *
 * Important: we do NOT cancel SplashOverlay#render(). That method also
 * contains the logic that detects when loading has finished and closes
 * the overlay - cancelling it would freeze the game on the loading
 * screen forever. Instead we draw our backdrop at HEAD (so it sits
 * behind vanilla's drawing) and then, at TAIL, paint over the region
 * where the Mojang logo and vanilla bar were drawn with our own themed
 * versions on top. The reload/completion logic in between runs
 * untouched.
 */
@Mixin(SplashOverlay.class)
public class SplashOverlayMixin {

    @Shadow
    private ResourceReload reload;

    @Inject(method = "render", at = @At("HEAD"))
    private void pikaclient$background(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        int w = client.getWindow().getScaledWidth();
        int h = client.getWindow().getScaledHeight();
        ctx.fill(0, 0, w, h, 0xFF242424);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void pikaclient$foreground(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        int w = client.getWindow().getScaledWidth();
        int h = client.getWindow().getScaledHeight();
        var tr = client.textRenderer;

        // Cover a generous band around center (where vanilla draws its logo
        // and bar) with our gray so nothing vanilla shows through, then draw
        // our own themed wordmark + bar on top of that band.
        int bandTop = h / 2 - 70, bandBottom = h / 2 + 40;
        ctx.fill(0, bandTop, w, bandBottom, 0xFF242424);

        String title = "PikaClient";
        int scale = 3;
        int titleWidth = tr.getWidth(title) * scale;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(w / 2f - titleWidth / 2f, h / 2f - 40, 0);
        ctx.getMatrices().scale(scale, scale);
        ctx.drawTextWithShadow(tr, title, 0, 0, RGBUtil.cycle(1.0f, 0, 255));
        ctx.getMatrices().popMatrix();

        float progress = 0f;
        if (reload != null) {
            progress = Math.max(0f, Math.min(1f, reload.getProgress()));
        }
        int barWidth = 240, barHeight = 6;
        int barX = w / 2 - barWidth / 2, barY = h / 2 + 10;
        ctx.fill(barX, barY, barX + barWidth, barY + barHeight, 0xFF3A3A3A);
        int filled = (int) (barWidth * progress);
        ctx.fill(barX, barY, barX + filled, barY + barHeight, RGBUtil.cycle(1.0f, 0, 255));
        ctx.drawBorder(barX, barY, barWidth, barHeight, 0x55FFFFFF);

        String pct = (int) (progress * 100) + "%";
        ctx.drawCenteredTextWithShadow(tr, pct, w / 2, barY + barHeight + 6, 0xFFAAAAAA);
    }
}
