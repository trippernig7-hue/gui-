package com.pika.client.cosmetics;

import com.pika.client.config.ConfigManager;
import com.pika.client.config.ModConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleTypes;

/**
 * Spawns the configured particle-trail cosmetic behind the local player
 * each tick. Purely visual client-side particles - no gameplay effect.
 */
public final class CosmeticEffects {

    private CosmeticEffects() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(CosmeticEffects::onTick);
    }

    private static void onTick(MinecraftClient client) {
        ModConfig c = ConfigManager.get();
        if (!c.particleTrail || client.player == null || client.world == null) return;

        var pos = client.player.getPos();
        double x = pos.x + (client.player.getRandom().nextDouble() - 0.5) * 0.3;
        double y = pos.y + 0.1;
        double z = pos.z + (client.player.getRandom().nextDouble() - 0.5) * 0.3;

        var type = switch (c.particleTrailType) {
            case "heart" -> ParticleTypes.HEART;
            case "sparkle" -> ParticleTypes.END_ROD;
            case "smoke" -> ParticleTypes.SMOKE;
            default -> ParticleTypes.FLAME;
        };

        client.world.addParticle(type, x, y, z, 0, 0.02, 0);
    }
}
