package com.pika.client.mixin;

import com.pika.client.PikaClient;
import com.pika.client.gui.ClickGuiScreen;
import com.pika.client.util.RGBUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Reskins the main menu: gray tint over the vanilla panorama, an animated
 * RGB accent strip, an FPS/RAM readout, and a shortcut button into the
 * PikaClient GUI.
 */
@Mixin(TitleScreen.class)
public class TitleScreenMixin {

    @Inject(method = "render", at = @At("HEAD"))
    private void pikaclient$grayTint(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        int w = MinecraftClient.getInstance().getWindow().getScaledWidth();
        int h = MinecraftClient.getInstance().getWindow().getScaledHeight();
        // Gray theme wash over the panorama
        ctx.fill(0, 0, w, h, 0x99202020);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void pikaclient$overlay(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        int w = client.getWindow().getScaledWidth();

        // Animated RGB strip along the very top of the screen.
        int segments = 40;
        for (int i = 0; i < segments; i++) {
            int x1 = (w * i) / segments, x2 = (w * (i + 1)) / segments;
            float t = i / (float) segments;
            int color = RGBUtil.lerp(
                    RGBUtil.cycle(PikaClient.config.rgbSpeed, 0, 255),
                    RGBUtil.cycle(PikaClient.config.rgbSpeed, 180, 255), t);
            ctx.fill(x1, 0, x2, 2, color);
        }

        // FPS / RAM readout, bottom-left, PikaClient branding bottom-right.
        long max = Runtime.getRuntime().maxMemory() / 1024 / 1024;
        long used = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024 / 1024;
        String stats = "FPS: " + client.getCurrentFps() + "  |  RAM: " + used + "/" + max + " MB";
        ctx.drawTextWithShadow(client.textRenderer, stats, 4, client.getWindow().getScaledHeight() - 12, 0xFFB0B0B0);
        ctx.drawTextWithShadow(client.textRenderer, "PikaClient",
                4, 4, RGBUtil.cycle(PikaClient.config.rgbSpeed, 0, 255));
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void pikaclient$addButton(CallbackInfo ci) {
        TitleScreen self = (TitleScreen) (Object) this;
        // Small shortcut button in the top-right corner to open the GUI
        // without needing to be in-world (Right Shift only works in-game).
        self.addDrawableChild(ButtonWidget.builder(Text.literal("PikaClient"), btn ->
                        MinecraftClient.getInstance().setScreen(new ClickGuiScreen()))
                .dimensions(self.width - 104, 4, 100, 20)
                .build());
    }
}
