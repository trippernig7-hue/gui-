package com.pika.client.cosmetics;

import com.pika.client.config.ConfigManager;
import com.pika.client.config.ModConfig;
import com.pika.client.util.RGBUtil;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Renders cosmetic geometry (cape, wings, halo, glow aura, pet marker) on
 * the client player model. These are simplified flat-quad models rather
 * than fully rigged 3D assets - functionally complete but intentionally
 * lightweight so the mod stays self-contained without a large asset pack.
 *
 * Note: cosmetics are rendered client-side only. Because there's no
 * network layer syncing PikaClient settings between players, other
 * players won't see your cosmetics unless a server-side companion
 * exists - this matches how most "client cosmetic" mods behave without
 * a backend service.
 */
public class CosmeticFeatureRenderer extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {

    private static final Identifier WHITE_TEXTURE = Identifier.of("pikaclient", "textures/cosmetics/white.png");

    public CosmeticFeatureRenderer(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                        AbstractClientPlayerEntity player, float limbAngle, float limbDistance,
                        float tickDelta, float animationProgress, float headYaw, float headPitch) {
        ModConfig c = ConfigManager.get();
        if (player.isInvisible()) return;

        matrices.push();

        if (c.capeEnabled) {
            renderCape(matrices, vertexConsumers, light, c, animationProgress);
        }
        if (c.wingsEnabled) {
            renderWings(matrices, vertexConsumers, light, c);
        }
        if (c.haloEnabled) {
            renderHalo(matrices, vertexConsumers, light, c);
        }
        if (c.glowEnabled) {
            renderGlowAura(matrices, vertexConsumers, light, c);
        }
        if (c.petEnabled && !c.petType.equals("none")) {
            renderPetMarker(matrices, vertexConsumers, light, c);
        }

        matrices.pop();
    }

    private VertexConsumer buffer(VertexConsumerProvider provider) {
        return provider.getBuffer(RenderLayer.getEntityTranslucent(WHITE_TEXTURE));
    }

    private void quad(VertexConsumer buf, Matrix4f mat, int color,
                       float x1, float y1, float z1, float x2, float y2, float z2,
                       float x3, float y3, float z3, float x4, float y4, float z4,
                       int light, Vector3f normal) {
        float a = ((color >> 24) & 0xFF) / 255f;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;
        buf.vertex(mat, x1, y1, z1).color(r, g, b, a).texture(0, 0).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(normal.x, normal.y, normal.z);
        buf.vertex(mat, x2, y2, z2).color(r, g, b, a).texture(1, 0).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(normal.x, normal.y, normal.z);
        buf.vertex(mat, x3, y3, z3).color(r, g, b, a).texture(1, 1).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(normal.x, normal.y, normal.z);
        buf.vertex(mat, x4, y4, z4).color(r, g, b, a).texture(0, 1).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(normal.x, normal.y, normal.z);
    }

    private void renderCape(MatrixStack matrices, VertexConsumerProvider provider, int light, ModConfig c, float animProgress) {
        matrices.push();
        matrices.translate(0, -0.2, 0.15); // anchor at upper back
        float sway = MathHelper.sin(animProgress * 0.15f) * 0.15f;
        matrices.multiply(new org.joml.Quaternionf().rotateX((float) Math.toRadians(8 + sway * 10)));

        int color = capeColor(c);
        VertexConsumer buf = buffer(provider);
        Matrix4f mat = matrices.peek().getPositionMatrix();
        float w = 0.5f, h = 1.0f;
        quad(buf, mat, color, -w, 0, 0, w, 0, 0, w, h, sway, -w, h, sway, light, new Vector3f(0, 0, 1));
        matrices.pop();
    }

    private int capeColor(ModConfig c) {
        return switch (c.capeStyle) {
            case "wave" -> RGBUtil.cycle(c.rgbSpeed, 0, 220);
            case "tattered" -> RGBUtil.withAlpha(0x552222, 200);
            case "royal" -> RGBUtil.withAlpha(c.primaryColorRGB, 230);
            default -> RGBUtil.withAlpha(c.secondaryColorRGB, 220);
        };
    }

    private void renderWings(MatrixStack matrices, VertexConsumerProvider provider, int light, ModConfig c) {
        matrices.push();
        matrices.translate(0, -0.1, 0.2);
        int color = switch (c.wingStyle) {
            case "demon" -> RGBUtil.withAlpha(0x991111, 210);
            case "dragon" -> RGBUtil.withAlpha(0x226622, 220);
            case "fairy" -> RGBUtil.cycle(c.rgbSpeed, 90, 200);
            default -> RGBUtil.withAlpha(0xFFFFFF, 210); // angel
        };
        VertexConsumer buf = buffer(provider);
        Matrix4f mat = matrices.peek().getPositionMatrix();
        // left wing
        quad(buf, mat, color, 0.2f, 0, 0, 1.1f, 0.2f, 0.1f, 1.0f, 0.9f, 0.1f, 0.2f, 0.8f, 0, light, new Vector3f(0, 0, 1));
        // right wing (mirrored)
        quad(buf, mat, color, -0.2f, 0, 0, -1.1f, 0.2f, 0.1f, -1.0f, 0.9f, 0.1f, -0.2f, 0.8f, 0, light, new Vector3f(0, 0, 1));
        matrices.pop();
    }

    private void renderHalo(MatrixStack matrices, VertexConsumerProvider provider, int light, ModConfig c) {
        matrices.push();
        matrices.translate(0, -1.75, 0); // above head
        VertexConsumer buf = buffer(provider);
        Matrix4f mat = matrices.peek().getPositionMatrix();
        int segments = 16;
        float radius = 0.35f;
        int color = RGBUtil.withAlpha(0xFFFFAA, 230);
        for (int i = 0; i < segments; i++) {
            float a1 = (float) (i * 2 * Math.PI / segments);
            float a2 = (float) ((i + 1) * 2 * Math.PI / segments);
            float x1 = MathHelper.cos(a1) * radius, z1 = MathHelper.sin(a1) * radius;
            float x2 = MathHelper.cos(a2) * radius, z2 = MathHelper.sin(a2) * radius;
            quad(buf, mat, color, x1, 0, z1, x2, 0, z2, x2, 0.05f, z2, x1, 0.05f, z1, light, new Vector3f(0, 1, 0));
        }
        matrices.pop();
    }

    private void renderGlowAura(MatrixStack matrices, VertexConsumerProvider provider, int light, ModConfig c) {
        // Simplified glow: a soft translucent vertical plane pair behind/in-front
        // of the player tinted with the configured glow color. A true per-pixel
        // outline shader would need a custom render pass; this keeps the effect
        // GPU-cheap and dependency-free.
        matrices.push();
        matrices.scale(1.15f, 1.15f, 1.15f);
        int color = RGBUtil.withAlpha(c.glowColorRGB, 60);
        VertexConsumer buf = buffer(provider);
        Matrix4f mat = matrices.peek().getPositionMatrix();
        quad(buf, mat, color, -0.4f, 0, 0, 0.4f, 0, 0, 0.4f, 1.8f, 0, -0.4f, 1.8f, 0, light, new Vector3f(0, 0, 1));
        matrices.pop();
    }

    private void renderPetMarker(MatrixStack matrices, VertexConsumerProvider provider, int light, ModConfig c) {
        matrices.push();
        matrices.translate(0.8, 0.9, 0.8);
        float bob = MathHelper.sin((System.currentTimeMillis() % 1000) / 1000f * (float) (2 * Math.PI)) * 0.05f;
        matrices.translate(0, bob, 0);
        int color = switch (c.petType) {
            case "cat" -> RGBUtil.withAlpha(0xCCCCCC, 230);
            case "dragon" -> RGBUtil.withAlpha(0x33AA33, 230);
            case "chicken" -> RGBUtil.withAlpha(0xFFFFFF, 230);
            default -> RGBUtil.withAlpha(0xFFFFFF, 200);
        };
        VertexConsumer buf = buffer(provider);
        Matrix4f mat = matrices.peek().getPositionMatrix();
        quad(buf, mat, color, -0.15f, 0, 0, 0.15f, 0, 0, 0.15f, 0.3f, 0, -0.15f, 0.3f, 0, light, new Vector3f(0, 0, 1));
        matrices.pop();
    }
}
