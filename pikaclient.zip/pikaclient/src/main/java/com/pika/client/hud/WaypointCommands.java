package com.pika.client.hud;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.text.Text;

/**
 * Registers the client-side "/pika waypoint" family of commands. These
 * are purely client-side (Brigadier ClientCommandManager), so they work
 * on any server without needing server-side support.
 */
public final class WaypointCommands {

    private WaypointCommands() {}

    public static void register() {
        ClientCommandManager.DISPATCHER.register(ClientCommandManager.literal("pika")
                .then(ClientCommandManager.literal("waypoint")
                        .then(ClientCommandManager.literal("add")
                                .then(ClientCommandManager.argument("name", StringArgumentType.word())
                                        .executes(WaypointCommands::addWaypoint)))
                        .then(ClientCommandManager.literal("clear")
                                .executes(ctx -> {
                                    WaypointManager.clear();
                                    ctx.getSource().sendFeedback(Text.literal("[PikaClient] Waypoints cleared."));
                                    return 1;
                                }))));
    }

    private static int addWaypoint(com.mojang.brigadier.context.CommandContext<FabricClientCommandSource> ctx) {
        String name = StringArgumentType.getString(ctx, "name");
        var player = ctx.getSource().getPlayer();
        var pos = player.getPos();
        WaypointManager.add(new WaypointManager.Waypoint(name, pos.x, pos.y, pos.z));
        ctx.getSource().sendFeedback(Text.literal("[PikaClient] Waypoint '" + name + "' added."));
        return 1;
    }
}
