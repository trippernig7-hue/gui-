package com.pika.client.util;

/**
 * Small helper for the animated RGB effects used across the GUI,
 * background, keystrokes HUD, and cosmetics glow.
 */
public final class RGBUtil {

    private RGBUtil() {}

    /**
     * Returns an ARGB color cycling smoothly through the hue wheel.
     *
     * @param speed      cycles per ~10 seconds, user-configurable
     * @param offsetDeg  phase offset in degrees, useful for staggering multiple elements
     * @param alpha      0-255 alpha channel
     */
    public static int cycle(float speed, float offsetDeg, int alpha) {
        long time = System.currentTimeMillis();
        float hue = ((time * speed * 0.00006f) + (offsetDeg / 360f)) % 1.0f;
        if (hue < 0) hue += 1.0f;
        int rgb = java.awt.Color.HSBtoRGB(hue, 0.85f, 1.0f) & 0xFFFFFF;
        return (alpha << 24) | rgb;
    }

    /** Linear interpolation between two ARGB colors. */
    public static int lerp(int colorA, int colorB, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aA = (colorA >> 24) & 0xFF, rA = (colorA >> 16) & 0xFF, gA = (colorA >> 8) & 0xFF, bA = colorA & 0xFF;
        int aB = (colorB >> 24) & 0xFF, rB = (colorB >> 16) & 0xFF, gB = (colorB >> 8) & 0xFF, bB = colorB & 0xFF;
        int a = (int) (aA + (aB - aA) * t);
        int r = (int) (rA + (rB - rA) * t);
        int g = (int) (gA + (gB - gA) * t);
        int b = (int) (bA + (bB - bA) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static int withAlpha(int rgb, int alpha) {
        return (alpha << 24) | (rgb & 0xFFFFFF);
    }
}
