package com.pika.client.hud;

import com.pika.client.config.ConfigManager;
import com.pika.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Owns the set of registered HUD elements, their on-screen positions, and
 * ALT+drag repositioning. Positions are persisted per-element in
 * {@code ModConfig.hudPositions}.
 */
public final class HudManager {

    private static final Map<String, HudElement> ELEMENTS = new LinkedHashMap<>();
    private static String draggingId = null;
    private static int dragOffsetX, dragOffsetY;

    private HudManager() {}

    public static void init() {
        register(HudElements.fps(), 6, 6);
        register(HudElements.ping(), 6, 20);
        register(HudElements.cps(), 6, 34);
        register(HudElements.memory(), 6, 48);
        register(HudElements.coords(), 6, 62);
        register(HudElements.direction(), 6, 76);
        register(HudElements.serverIp(), 6, 90);
        register(HudElements.keystrokes(), 6, 110);
        register(HudElements.armorPotions(), 6, 180);
        register(HudElements.compass(), -1, 6); // -1 = auto-center horizontally
        register(HudElements.minimap(), -100, 6); // -100 = anchor to right edge, 100px in
        register(HudElements.waypoints(), 6, 250);
    }

    private static void register(HudElement element, int defaultX, int defaultY) {
        ELEMENTS.put(element.id(), element);
        ModConfig c = ConfigManager.get();
        c.hudPositions.putIfAbsent(element.id(), new int[]{defaultX, defaultY});
    }

    public static void render(DrawContext ctx, MinecraftClient client) {
        if (client.player == null || client.options.hudHidden) return;
        ModConfig c = ConfigManager.get();

        for (HudElement element : ELEMENTS.values()) {
            if (!element.isEnabled()) continue;
            int[] pos = resolvePosition(element, c, client);

            ctx.getMatrices().pushMatrix();
            ctx.getMatrices().translate(pos[0], pos[1]);
            ctx.getMatrices().scale(c.hudScale, c.hudScale);
            element.render(ctx, client, 0, 0, c.hudOpacity, c.hudScale);
            ctx.getMatrices().popMatrix();

            if (element.id().equals(draggingId)) {
                ctx.drawBorder(pos[0] - 2, pos[1] - 2,
                        (int) (element.width() * c.hudScale) + 4,
                        (int) (element.height() * c.hudScale) + 4, 0xFFFFFFFF);
            }
        }
    }

    private static int[] resolvePosition(HudElement element, ModConfig c, MinecraftClient client) {
        int[] stored = c.hudPositions.get(element.id());
        int x = stored[0], y = stored[1];
        if (x == -1) x = (client.getWindow().getScaledWidth() - element.width()) / 2;
        if (x <= -50) x = client.getWindow().getScaledWidth() + x - element.width() + 100;
        if (y == -1) y = (client.getWindow().getScaledHeight() - element.height()) / 2;
        return new int[]{x, y};
    }

    /**
     * Called from {@code MouseMixin} on left-mouse-down while ALT is held and
     * no screen is open. Starts dragging whichever element the cursor is over.
     */
    public static boolean tryStartDrag(double mouseX, double mouseY) {
        MinecraftClient client = MinecraftClient.getInstance();
        ModConfig c = ConfigManager.get();
        for (HudElement element : ELEMENTS.values()) {
            if (!element.isEnabled()) continue;
            int[] pos = resolvePosition(element, c, client);
            int w = (int) (element.width() * c.hudScale);
            int h = (int) (element.height() * c.hudScale);
            if (mouseX >= pos[0] && mouseX <= pos[0] + w && mouseY >= pos[1] && mouseY <= pos[1] + h) {
                draggingId = element.id();
                dragOffsetX = (int) (mouseX - pos[0]);
                dragOffsetY = (int) (mouseY - pos[1]);
                return true;
            }
        }
        return false;
    }

    public static void updateDrag(double mouseX, double mouseY) {
        if (draggingId == null) return;
        ModConfig c = ConfigManager.get();
        int[] pos = c.hudPositions.get(draggingId);
        pos[0] = (int) (mouseX - dragOffsetX);
        pos[1] = (int) (mouseY - dragOffsetY);
    }

    public static void stopDrag() {
        if (draggingId != null) {
            ConfigManager.save();
        }
        draggingId = null;
    }

    public static boolean isDragging() {
        return draggingId != null;
    }

    /** Applies a built-in layout/visibility preset, matching the HUD tab's dropdown. */
    public static void applyPreset(String preset) {
        ModConfig c = ConfigManager.get();
        switch (preset) {
            case "minimal" -> {
                c.hudFps = true; c.hudPing = false; c.hudCps = false; c.hudKeystrokes = false;
                c.hudCoords = false; c.hudDirection = false; c.hudMemory = false;
                c.hudCompass = false; c.hudMinimap = false; c.hudWaypoints = false;
            }
            case "compact" -> {
                c.hudFps = true; c.hudPing = true; c.hudCps = true; c.hudKeystrokes = false;
                c.hudCoords = true; c.hudDirection = false; c.hudMemory = false;
                c.hudCompass = true; c.hudMinimap = false; c.hudWaypoints = false;
            }
            case "full" -> {
                c.hudFps = true; c.hudPing = true; c.hudCps = true; c.hudKeystrokes = true;
                c.hudCoords = true; c.hudDirection = true; c.hudMemory = true;
                c.hudCompass = true; c.hudMinimap = true; c.hudWaypoints = true;
            }
            default -> {
                c.hudFps = true; c.hudPing = true; c.hudCps = true; c.hudKeystrokes = true;
                c.hudCoords = true; c.hudDirection = true; c.hudMemory = false;
                c.hudCompass = true; c.hudMinimap = true; c.hudWaypoints = true;
            }
        }
        c.hudPreset = preset;
        ConfigManager.save();
    }
}
