package com.pika.client;

import com.pika.client.config.ConfigManager;
import com.pika.client.config.ModConfig;
import com.pika.client.cosmetics.CosmeticEffects;
import com.pika.client.gui.ClickGuiScreen;
import com.pika.client.hud.HudManager;
import com.pika.client.keybinds.KeyBindings;
import com.pika.client.util.PerformanceManager;
import com.pika.client.util.VisualsManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;

/**
 * PikaClient - a cosmetic / QoL / performance Fabric client mod.
 *
 * Deliberately excludes any feature that would grant an unfair advantage
 * in multiplayer (no reach modification, no ESP/tracers, no hitbox
 * expansion, no fall-damage bypass, no forced fullbright). Everything
 * here is HUD, visuals, performance tuning, and cosmetics.
 */
public class PikaClient implements ClientModInitializer {

    public static final String MOD_ID = "pikaclient";
    public static ModConfig config;

    private boolean wasOpenGuiPressed = false;

    @Override
    public void onInitializeClient() {
        config = ConfigManager.get();

        KeyBindings.register();
        HudManager.init();
        com.pika.client.hud.WaypointCommands.register();
        CosmeticEffects.init();
        PerformanceManager.init();
        VisualsManager.init();

        // Open the click-GUI on Right Shift press (handled every tick since
        // KeyBinding#wasPressed() would also fire while a screen is open and
        // consume repeated presses awkwardly - we do simple edge detection).
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);

        // Draw the HUD overlay every frame.
        HudRenderCallback.EVENT.register((drawContext, tickDelta) ->
                HudManager.render(drawContext, MinecraftClient.getInstance()));

        // Save config on shutdown so nothing is lost.
        Runtime.getRuntime().addShutdownHook(new Thread(ConfigManager::save));

        System.out.println("[PikaClient] Initialized (fair-play build - no reach/ESP/hitbox/nofall/fullbright).");
    }

    private void onClientTick(MinecraftClient client) {
        boolean pressed = KeyBindings.OPEN_GUI.isPressed();
        if (pressed && !wasOpenGuiPressed && client.currentScreen == null) {
            client.setScreen(new ClickGuiScreen());
        }
        wasOpenGuiPressed = pressed;

        // Toggle-sprint / toggle-sneak: flip the persistent flag on key press,
        // the actual holding of the vanilla state is applied in
        // ClientPlayerEntityMixin so it interacts correctly with movement code.
        if (KeyBindings.TOGGLE_SPRINT.wasPressed()) {
            config.sprintToggle = !config.sprintToggle;
        }
        if (KeyBindings.TOGGLE_SNEAK.wasPressed()) {
            config.sneakToggle = !config.sneakToggle;
        }

        // Keystrokes HUD state: read directly from the player's movement
        // input each tick rather than hooking raw key events, since we only
        // need current held/not-held state (not precise timing like clicks).
        if (client.player != null) {
            var input = client.player.input;
            com.pika.client.util.InputTracker.forward = input.movementForward > 0;
            com.pika.client.util.InputTracker.back = input.movementForward < 0;
            com.pika.client.util.InputTracker.left = input.movementSideways > 0;
            com.pika.client.util.InputTracker.right = input.movementSideways < 0;
            com.pika.client.util.InputTracker.jump = client.options.jumpKey.isPressed();
        }
    }
}
