package com.pika.client.gui;

import com.pika.client.config.ConfigManager;
import com.pika.client.config.ModConfig;
import com.pika.client.gui.widget.PikaWidget;
import com.pika.client.util.RGBUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * The main PikaClient GUI: an RGB-animated, blurred panel with a tab strip
 * on the left and the selected category's controls on the right.
 */
public class ClickGuiScreen extends Screen {

    private static final int PANEL_WIDTH = 480;
    private static final int PANEL_HEIGHT = 320;
    private static final int TAB_STRIP_WIDTH = 130;

    private GuiTabs.Tab selectedTab = GuiTabs.Tab.GAMEPLAY;
    private final Map<GuiTabs.Tab, List<PikaWidget>> tabWidgets = new EnumMap<>(GuiTabs.Tab.class);
    private int scrollOffset = 0;

    public ClickGuiScreen() {
        super(Text.literal("PikaClient"));
    }

    @Override
    protected void init() {
        int contentWidth = PANEL_WIDTH - TAB_STRIP_WIDTH - 24;
        for (GuiTabs.Tab tab : GuiTabs.Tab.values()) {
            tabWidgets.put(tab, GuiTabs.build(tab, contentWidth));
        }
        layoutCurrentTab();
    }

    private void layoutCurrentTab() {
        int contentWidth = PANEL_WIDTH - TAB_STRIP_WIDTH - 24;
        int panelX = (this.width - PANEL_WIDTH) / 2;
        int panelY = (this.height - PANEL_HEIGHT) / 2;
        int startX = panelX + TAB_STRIP_WIDTH + 16;
        int startY = panelY + 40 - scrollOffset;

        int curY = startY;
        for (PikaWidget w : tabWidgets.get(selectedTab)) {
            w.setPosition(startX, curY);
            curY += w.getHeight() + 6;
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ModConfig c = ConfigManager.get();

        // Dim + blur the game world behind the GUI.
        this.renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(0, 0, this.width, this.height, 0x99000000);

        int panelX = (this.width - PANEL_WIDTH) / 2;
        int panelY = (this.height - PANEL_HEIGHT) / 2;
        int alpha = (int) (c.guiOpacity * 255) << 24;

        // Animated RGB border using the two theme colors + live hue cycle.
        int rgbA = RGBUtil.cycle(c.rgbSpeed, 0, 255);
        int rgbB = RGBUtil.cycle(c.rgbSpeed, 120, 255);

        drawPanelBackground(ctx, panelX, panelY, PANEL_WIDTH, PANEL_HEIGHT, alpha, rgbA, rgbB);

        // Title bar
        ctx.drawTextWithShadow(this.textRenderer, "PikaClient", panelX + 16, panelY + 12, 0xFFFFFFFF);
        String sub = selectedTab.displayName;
        ctx.drawTextWithShadow(this.textRenderer, sub, panelX + TAB_STRIP_WIDTH + 16, panelY + 20, RGBUtil.cycle(c.rgbSpeed, 60, 255));

        // Tab strip
        int tabY = panelY + 40;
        for (GuiTabs.Tab tab : GuiTabs.Tab.values()) {
            boolean selected = tab == selectedTab;
            int tx = panelX + 12, ty = tabY;
            int tw = TAB_STRIP_WIDTH - 20, th = 22;
            boolean hovered = mouseX >= tx && mouseX <= tx + tw && mouseY >= ty && mouseY <= ty + th;
            int bg = selected ? RGBUtil.withAlpha(c.accentColorRGB, 200) : (hovered ? 0x30FFFFFF : 0x18FFFFFF);
            ctx.fill(tx, ty, tx + tw, ty + th, bg);
            ctx.drawTextWithShadow(this.textRenderer, tab.displayName, tx + 8, ty + 7, 0xFFF0F0F0);
            tabY += th + 4;
        }

        // Content panel clip area (simple scissor via fill boundaries; DrawContext doesn't
        // need explicit scissor for our simple non-overlapping list layout).
        for (PikaWidget w : tabWidgets.get(selectedTab)) {
            w.render(ctx, mouseX, mouseY, RGBUtil.cycle(c.rgbSpeed, 0, 255));
        }

        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawPanelBackground(DrawContext ctx, int x, int y, int w, int h, int alpha, int rgbA, int rgbB) {
        // Base gray panel
        int base = 0xFF1E1E1E & 0x00FFFFFF | alpha;
        ctx.fill(x, y, x + w, y + h, base);

        // Animated gradient strip along the top for the "RGB animated background" feel.
        int stripH = 3;
        int segments = 32;
        for (int i = 0; i < segments; i++) {
            int sx1 = x + (w * i) / segments;
            int sx2 = x + (w * (i + 1)) / segments;
            float t = i / (float) segments;
            int c = RGBUtil.lerp(rgbA, rgbB, t);
            ctx.fill(sx1, y, sx2, y + stripH, c);
        }

        ctx.drawBorder(x, y, w, h, 0x55FFFFFF);

        // Tab strip separator
        ctx.fill(x + TAB_STRIP_WIDTH, y + 4, x + TAB_STRIP_WIDTH + 1, y + h - 4, 0x33FFFFFF);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int panelX = (this.width - PANEL_WIDTH) / 2;
        int py = (this.height - PANEL_HEIGHT) / 2 + 40;

        // Tab strip clicks
        for (GuiTabs.Tab tab : GuiTabs.Tab.values()) {
            int tx = panelX + 12, ty = py;
            int tw = TAB_STRIP_WIDTH - 20, th = 22;
            if (mouseX >= tx && mouseX <= tx + tw && mouseY >= ty && mouseY <= ty + th) {
                selectedTab = tab;
                scrollOffset = 0;
                layoutCurrentTab();
                return true;
            }
            py += th + 4;
        }

        for (PikaWidget w : tabWidgets.get(selectedTab)) {
            if (w.mouseClicked(mouseX, mouseY, button)) {
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        for (PikaWidget w : tabWidgets.get(selectedTab)) {
            if (w.mouseDragged(mouseX, mouseY, button, deltaX, deltaY)) {
                return true;
            }
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (PikaWidget w : tabWidgets.get(selectedTab)) {
            w.mouseReleased(mouseX, mouseY, button);
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollOffset = Math.max(0, scrollOffset - (int) (verticalAmount * 16));
        layoutCurrentTab();
        return true;
    }

    @Override
    public void close() {
        ConfigManager.save();
        super.close();
    }

    @Override
    public boolean shouldPause() {
        return false; // GUI can be opened without pausing an SMP/singleplayer game
    }
}
