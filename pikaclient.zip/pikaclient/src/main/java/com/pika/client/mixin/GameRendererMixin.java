package com.pika.client.mixin;

import com.pika.client.PikaClient;
import com.pika.client.keybinds.KeyBindings;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Implements the zoom feature by narrowing the FOV while the zoom key is
 * held - identical in effect to zoom mods like OptiFine's or Sodium
 * extensions'. This does NOT change hitboxes, reach, or aiming precision
 * beyond what a narrower FOV naturally gives a human aiming by eye, which
 * is the same tradeoff vanilla FOV settings already offer.
 */
@Mixin(GameRenderer.class)
public class GameRendererMixin {

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void pikaclient$applyZoom(net.minecraft.client.render.Camera camera, float tickDelta,
                                       boolean changingFov, CallbackInfoReturnable<Double> cir) {
        if (PikaClient.config.zoomEnabled && KeyBindings.ZOOM.isPressed()) {
            double base = cir.getReturnValue();
            cir.setReturnValue(Math.min(base, PikaClient.config.zoomFov));
        }
    }
}
