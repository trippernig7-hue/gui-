package com.pika.client.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * A single draggable HUD element (FPS counter, coords, minimap, etc.).
 * Position is stored in {@code ModConfig.hudPositions} keyed by {@link #id()}
 * so placement survives restarts.
 */
public interface HudElement {

    String id();

    /** Whether this element should currently be drawn, per user config. */
    boolean isEnabled();

    /** Rough width/height used for drag hit-testing and default layout. */
    int width();
    int height();

    void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale);
}
