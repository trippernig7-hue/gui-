package com.pika.client.keybinds;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * All PikaClient keybinds. Registered once during client init.
 * None of these bypass vanilla input handling - they toggle mod-side
 * state (open a screen, hold-to-zoom, toggle sprint/sneak flags).
 */
public final class KeyBindings {

    public static final String CATEGORY = "category.pikaclient.main";

    public static final KeyBinding OPEN_GUI = new KeyBinding(
            "key.pikaclient.open_gui",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            CATEGORY
    );

    public static final KeyBinding ZOOM = new KeyBinding(
            "key.pikaclient.zoom",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_C,
            CATEGORY
    );

    public static final KeyBinding TOGGLE_SPRINT = new KeyBinding(
            "key.pikaclient.toggle_sprint",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_R,
            CATEGORY
    );

    public static final KeyBinding TOGGLE_SNEAK = new KeyBinding(
            "key.pikaclient.toggle_sneak",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_UNKNOWN, // unbound by default, user can bind in vanilla controls menu
            CATEGORY
    );

    private KeyBindings() {}

    public static void register() {
        KeyBindingHelper.registerKeyBinding(OPEN_GUI);
        KeyBindingHelper.registerKeyBinding(ZOOM);
        KeyBindingHelper.registerKeyBinding(TOGGLE_SPRINT);
        KeyBindingHelper.registerKeyBinding(TOGGLE_SNEAK);
    }
}
