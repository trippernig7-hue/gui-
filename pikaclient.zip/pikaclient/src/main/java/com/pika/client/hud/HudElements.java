package com.pika.client.hud;

import com.pika.client.config.ConfigManager;
import com.pika.client.config.ModConfig;
import com.pika.client.util.InputTracker;
import com.pika.client.util.RGBUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;

import java.util.List;

/**
 * Factory for all built-in HUD elements. Each one reads live game state
 * from {@link MinecraftClient} and honors the enable-toggles in
 * {@link ModConfig}. Kept in one file since each element is short.
 */
public final class HudElements {

    private HudElements() {}

    private static int textColor(float opacity) {
        return ((int) (opacity * 255) << 24) | 0xFFFFFF;
    }

    public static HudElement fps() {
        return new HudElement() {
            public String id() { return "fps"; }
            public boolean isEnabled() { return ConfigManager.get().hudFps; }
            public int width() { return 70; }
            public int height() { return 12; }
            public void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale) {
                int fps = client.getCurrentFps();
                ctx.drawTextWithShadow(client.textRenderer, "FPS: " + fps, x, y, textColor(opacity));
            }
        };
    }

    public static HudElement ping() {
        return new HudElement() {
            public String id() { return "ping"; }
            public boolean isEnabled() { return ConfigManager.get().hudPing; }
            public int width() { return 80; }
            public int height() { return 12; }
            public void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale) {
                int ping = 0;
                if (client.player != null && client.getNetworkHandler() != null) {
                    PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
                    if (entry != null) ping = entry.getLatency();
                }
                ctx.drawTextWithShadow(client.textRenderer, "Ping: " + ping + "ms", x, y, textColor(opacity));
            }
        };
    }

    public static HudElement cps() {
        return new HudElement() {
            public String id() { return "cps"; }
            public boolean isEnabled() { return ConfigManager.get().hudCps; }
            public int width() { return 90; }
            public int height() { return 12; }
            public void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale) {
                String txt = "CPS: " + InputTracker.getLeftCps() + " | " + InputTracker.getRightCps();
                ctx.drawTextWithShadow(client.textRenderer, txt, x, y, textColor(opacity));
            }
        };
    }

    public static HudElement memory() {
        return new HudElement() {
            public String id() { return "memory"; }
            public boolean isEnabled() { return ConfigManager.get().hudMemory; }
            public int width() { return 120; }
            public int height() { return 12; }
            public void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale) {
                long max = Runtime.getRuntime().maxMemory() / 1024 / 1024;
                long used = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024 / 1024;
                ctx.drawTextWithShadow(client.textRenderer, "Mem: " + used + "/" + max + " MB", x, y, textColor(opacity));
            }
        };
    }

    public static HudElement coords() {
        return new HudElement() {
            public String id() { return "coords"; }
            public boolean isEnabled() { return ConfigManager.get().hudCoords; }
            public int width() { return 140; }
            public int height() { return 12; }
            public void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale) {
                if (client.player == null) return;
                var pos = client.player.getPos();
                String txt = String.format("XYZ: %.1f / %.1f / %.1f", pos.x, pos.y, pos.z);
                ctx.drawTextWithShadow(client.textRenderer, txt, x, y, textColor(opacity));
            }
        };
    }

    public static HudElement direction() {
        return new HudElement() {
            public String id() { return "direction"; }
            public boolean isEnabled() { return ConfigManager.get().hudDirection; }
            public int width() { return 100; }
            public int height() { return 12; }
            public void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale) {
                if (client.player == null) return;
                float yaw = MathHelper.wrapDegrees(client.player.getYaw());
                String dir;
                if (yaw >= -22.5 && yaw < 22.5) dir = "South";
                else if (yaw >= 22.5 && yaw < 67.5) dir = "South West";
                else if (yaw >= 67.5 && yaw < 112.5) dir = "West";
                else if (yaw >= 112.5 && yaw < 157.5) dir = "North West";
                else if (yaw >= 157.5 || yaw < -157.5) dir = "North";
                else if (yaw >= -157.5 && yaw < -112.5) dir = "North East";
                else if (yaw >= -112.5 && yaw < -67.5) dir = "East";
                else dir = "South East";
                ctx.drawTextWithShadow(client.textRenderer, dir + String.format(" (%.0f\u00B0)", yaw), x, y, textColor(opacity));
            }
        };
    }

    public static HudElement serverIp() {
        return new HudElement() {
            public String id() { return "server_ip"; }
            public boolean isEnabled() { return ConfigManager.get().hudServerIp; }
            public int width() { return 160; }
            public int height() { return 12; }
            public void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale) {
                String ip = "Singleplayer";
                if (client.getCurrentServerEntry() != null) {
                    ip = client.getCurrentServerEntry().address;
                }
                ctx.drawTextWithShadow(client.textRenderer, "Server: " + ip, x, y, textColor(opacity));
            }
        };
    }

    public static HudElement keystrokes() {
        return new HudElement() {
            public String id() { return "keystrokes"; }
            public boolean isEnabled() { return ConfigManager.get().hudKeystrokes; }
            public int width() { return 62; }
            public int height() { return 62; }
            public void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale) {
                ModConfig c = ConfigManager.get();
                int size = 18, gap = 2;
                drawKey(ctx, client, x + size + gap, y, size, "W", InputTracker.forward, c, opacity);
                drawKey(ctx, client, x, y + size + gap, size, "A", InputTracker.left, c, opacity);
                drawKey(ctx, client, x + size + gap, y + size + gap, size, "S", InputTracker.back, c, opacity);
                drawKey(ctx, client, x + (size + gap) * 2, y + size + gap, size, "D", InputTracker.right, c, opacity);
            }

            private void drawKey(DrawContext ctx, MinecraftClient client, int kx, int ky, int size,
                                  String label, boolean active, ModConfig c, float opacity) {
                int bg = active
                        ? (c.hudKeystrokesRgb ? RGBUtil.cycle(c.rgbSpeed, 0, (int) (opacity * 255))
                                              : RGBUtil.withAlpha(c.accentColorRGB, (int) (opacity * 255)))
                        : (0x66000000 | ((int) (opacity * 100) << 24));
                ctx.fill(kx, ky, kx + size, ky + size, bg);
                ctx.drawBorder(kx, ky, size, size, 0x55FFFFFF);
                int tw = client.textRenderer.getWidth(label);
                ctx.drawTextWithShadow(client.textRenderer, label, kx + (size - tw) / 2, ky + (size - 8) / 2, 0xFFFFFFFF);
            }
        };
    }

    public static HudElement armorPotions() {
        return new HudElement() {
            public String id() { return "armor_potions"; }
            public boolean isEnabled() {
                ModConfig c = ConfigManager.get();
                return c.armorStatusHud || c.potionStatusHud;
            }
            public int width() { return 120; }
            public int height() { return 60; }
            public void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale) {
                if (client.player == null) return;
                ModConfig c = ConfigManager.get();
                int curY = y;
                if (c.armorStatusHud) {
                    PlayerEntity p = client.player;
                    List<ItemStack> armor = List.of(
                            p.getEquippedStack(net.minecraft.entity.EquipmentSlot.HEAD),
                            p.getEquippedStack(net.minecraft.entity.EquipmentSlot.CHEST),
                            p.getEquippedStack(net.minecraft.entity.EquipmentSlot.LEGS),
                            p.getEquippedStack(net.minecraft.entity.EquipmentSlot.FEET)
                    );
                    int ix = x;
                    for (ItemStack stack : armor) {
                        if (!stack.isEmpty()) {
                            ctx.drawItem(stack, ix, curY);
                            ix += 18;
                        }
                    }
                    curY += 20;
                }
                if (c.potionStatusHud) {
                    for (StatusEffectInstance effect : client.player.getStatusEffects()) {
                        String name = effect.getEffectType().value().getName().getString();
                        String txt = name + " " + (effect.getAmplifier() + 1);
                        ctx.drawTextWithShadow(client.textRenderer, txt, x, curY, textColor(opacity));
                        curY += 10;
                    }
                }
            }
        };
    }

    public static HudElement compass() {
        return new HudElement() {
            public String id() { return "compass"; }
            public boolean isEnabled() { return ConfigManager.get().hudCompass; }
            public int width() { return 182; }
            public int height() { return 14; }
            public void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale) {
                if (client.player == null) return;
                ctx.fill(x, y, x + width(), y + height(), (int) (opacity * 120) << 24);
                float yaw = MathHelper.wrapDegrees(client.player.getYaw());
                String[] marks = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
                int center = x + width() / 2;
                for (int i = -4; i <= 4; i++) {
                    float markYaw = yaw + i * 22.5f;
                    int idx = Math.floorMod(Math.round(markYaw / 45f) + 2, 8);
                    int mx = center + i * 20;
                    if (i % 2 == 0) {
                        ctx.drawTextWithShadow(client.textRenderer, marks[idx], mx - 3, y + 2, textColor(opacity));
                    }
                }
                ctx.fill(center - 1, y, center + 1, y + height(), 0xFFFF5555);
            }
        };
    }

    /**
     * A simplified radar-style minimap: draws a circular frame, the player's
     * facing direction, and dots for nearby players. A full terrain minimap
     * would require rendering chunks to an off-screen texture; that's a
     * reasonable follow-up but out of scope for this pass.
     */
    public static HudElement minimap() {
        return new HudElement() {
            public String id() { return "minimap"; }
            public boolean isEnabled() { return ConfigManager.get().hudMinimap; }
            public int width() { return 100; }
            public int height() { return 100; }
            public void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale) {
                if (client.player == null || client.world == null) return;
                int cx = x + width() / 2, cy = y + height() / 2, radius = width() / 2;
                int bg = (int) (opacity * 160) << 24 | 0x101010;
                ctx.fill(x, y, x + width(), y + height(), bg);
                ctx.drawBorder(x, y, width(), height(), RGBUtil.withAlpha(ConfigManager.get().accentColorRGB, 255));

                double range = 64.0; // blocks shown edge-to-edge
                var selfPos = client.player.getPos();
                float yaw = client.player.getYaw();

                for (var entity : client.world.getPlayers()) {
                    if (entity == client.player) continue;
                    double dx = entity.getX() - selfPos.x;
                    double dz = entity.getZ() - selfPos.z;
                    // rotate relative to player's facing so "up" is always forward
                    double rad = Math.toRadians(yaw);
                    double rx = dx * Math.cos(rad) + dz * Math.sin(rad);
                    double rz = -dx * Math.sin(rad) + dz * Math.cos(rad);
                    int px = (int) (cx + (rx / range) * radius);
                    int pz = (int) (cy + (rz / range) * radius);
                    if (Math.hypot(px - cx, pz - cy) <= radius) {
                        ctx.fill(px - 1, pz - 1, px + 2, pz + 2, 0xFFFFFF55);
                    }
                }
                // player marker (always center, arrow pointing "up")
                ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFF4444);
            }
        };
    }

    /** A single example waypoint HUD readout (distance/direction to a set point). */
    public static HudElement waypoints() {
        return new HudElement() {
            public String id() { return "waypoints"; }
            public boolean isEnabled() { return ConfigManager.get().hudWaypoints; }
            public int width() { return 150; }
            public int height() { return 12; }
            public void render(DrawContext ctx, MinecraftClient client, int x, int y, float opacity, float scale) {
                if (client.player == null || WaypointManager.getActive() == null) return;
                var wp = WaypointManager.getActive();
                double dist = client.player.getPos().distanceTo(
                        new net.minecraft.util.math.Vec3d(wp.x(), wp.y(), wp.z()));
                String txt = String.format("%s: %.0fm", wp.name(), dist);
                ctx.drawTextWithShadow(client.textRenderer, txt, x, y, textColor(opacity));
            }
        };
    }
}
