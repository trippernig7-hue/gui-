package com.pika.client.gui.widget;

import net.minecraft.client.gui.DrawContext;

/** A simple full-width action button (e.g. "Optimize Now", "Export Settings"). */
public class ActionButtonWidget extends PikaWidget {

    private final Runnable action;

    public ActionButtonWidget(String label, int panelWidth, Runnable action) {
        super(label, panelWidth, 20);
        this.action = action;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, int accentColor) {
        boolean hovered = isHovered(mouseX, mouseY);
        int bg = hovered ? accentColor : 0x33FFFFFF;
        ctx.fill(x, y, x + width, y + height, bg);
        var tr = net.minecraft.client.MinecraftClient.getInstance().textRenderer;
        int tw = tr.getWidth(label);
        ctx.drawTextWithShadow(tr, label, x + (width - tw) / 2, y + 6, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && isHovered(mouseX, mouseY)) {
            action.run();
            return true;
        }
        return false;
    }
}
