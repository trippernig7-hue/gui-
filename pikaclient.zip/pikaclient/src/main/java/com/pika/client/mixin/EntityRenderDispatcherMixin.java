package com.pika.client.mixin;

import com.pika.client.PikaClient;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Performance-tab "Entity Culling": skips rendering entities beyond the
 * configured entity-distance percentage of the current render distance.
 * This only affects how far away entities are drawn (a pure performance
 * knob, identical in spirit to vanilla's own entity distance slider) -
 * it never affects hit detection, which is handled server-side and by
 * unrelated client systems regardless of what's drawn on screen.
 */
@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {

    @Inject(
            method = "render(Lnet/minecraft/entity/Entity;DDDFFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private <E extends Entity> void pikaclient$cullByDistance(E entity, double x, double y, double z, float yaw,
                                                                float tickDelta, MatrixStack matrices,
                                                                VertexConsumerProvider vertexConsumers, int light,
                                                                CallbackInfo ci) {
        if (!PikaClient.config.entityCullingPerf) return;
        var camera = net.minecraft.client.MinecraftClient.getInstance().gameRenderer.getCamera();
        if (camera == null || camera.getPos() == null) return;

        double dx = x - camera.getPos().x;
        double dy = y - camera.getPos().y;
        double dz = z - camera.getPos().z;
        double distSq = dx * dx + dy * dy + dz * dz;

        double maxDistance = PikaClient.config.renderDistance * 16.0 * (PikaClient.config.entityDistance / 100.0);
        if (distSq > maxDistance * maxDistance && entity != net.minecraft.client.MinecraftClient.getInstance().player) {
            ci.cancel();
        }
    }
}
