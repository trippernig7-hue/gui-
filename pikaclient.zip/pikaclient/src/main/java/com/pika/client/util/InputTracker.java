package com.pika.client.util;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Tracks left/right click timestamps for a CPS (clicks-per-second) counter,
 * and current WASD/mouse button states for the keystrokes HUD.
 * Fed by {@code MouseMixin} and {@code KeyboardMixin}.
 */
public final class InputTracker {

    private static final Deque<Long> LEFT_CLICKS = new ArrayDeque<>();
    private static final Deque<Long> RIGHT_CLICKS = new ArrayDeque<>();

    public static boolean forward, back, left, right, jump;
    public static boolean leftMouseDown, rightMouseDown;

    private InputTracker() {}

    public static void onLeftClick() {
        LEFT_CLICKS.addLast(System.currentTimeMillis());
        pruneOld(LEFT_CLICKS);
    }

    public static void onRightClick() {
        RIGHT_CLICKS.addLast(System.currentTimeMillis());
        pruneOld(RIGHT_CLICKS);
    }

    private static void pruneOld(Deque<Long> deque) {
        long now = System.currentTimeMillis();
        while (!deque.isEmpty() && now - deque.peekFirst() > 1000) {
            deque.pollFirst();
        }
    }

    /** Combined CPS (left + right), matching how most HUD clients display it. */
    public static int getCps() {
        pruneOld(LEFT_CLICKS);
        pruneOld(RIGHT_CLICKS);
        return LEFT_CLICKS.size() + RIGHT_CLICKS.size();
    }

    public static int getLeftCps() {
        pruneOld(LEFT_CLICKS);
        return LEFT_CLICKS.size();
    }

    public static int getRightCps() {
        pruneOld(RIGHT_CLICKS);
        return RIGHT_CLICKS.size();
    }
}
