package com.pika.client.gui.widget;

import net.minecraft.client.gui.DrawContext;

/**
 * Minimal shared contract for PikaClient's hand-rolled GUI controls.
 * We don't extend vanilla ClickableWidget for these because the panel
 * itself handles layout/scrolling; each widget just needs to draw and
 * respond to a click within its bounds.
 */
public abstract class PikaWidget {

    protected int x, y, width, height;
    protected final String label;

    protected PikaWidget(String label, int width, int height) {
        this.label = label;
        this.width = width;
        this.height = height;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getHeight() {
        return height;
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    public abstract void render(DrawContext ctx, int mouseX, int mouseY, int accentColor);

    /** @return true if this widget consumed the click */
    public abstract boolean mouseClicked(double mouseX, double mouseY, int button);

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return false;
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {}
}
