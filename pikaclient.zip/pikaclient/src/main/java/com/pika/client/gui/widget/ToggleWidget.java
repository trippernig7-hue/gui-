package com.pika.client.gui.widget;

import net.minecraft.client.gui.DrawContext;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** A labeled on/off switch, styled as a pill with a sliding knob. */
public class ToggleWidget extends PikaWidget {

    private final BooleanSupplier getter;
    private final Consumer<Boolean> setter;

    public ToggleWidget(String label, int panelWidth, BooleanSupplier getter, Consumer<Boolean> setter) {
        super(label, panelWidth, 20);
        this.getter = getter;
        this.setter = setter;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, int accentColor) {
        boolean hovered = isHovered(mouseX, mouseY);
        boolean state = getter.getAsBoolean();

        if (hovered) {
            ctx.fill(x, y, x + width, y + height, 0x22FFFFFF);
        }
        ctx.drawTextWithShadow(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                label, x + 4, y + 6, 0xFFEAEAEA);

        int switchWidth = 28, switchHeight = 12;
        int sx = x + width - switchWidth - 6;
        int sy = y + (height - switchHeight) / 2;
        int track = state ? accentColor : 0xFF4A4A4A;
        ctx.fill(sx, sy, sx + switchWidth, sy + switchHeight, track);

        int knobSize = 10;
        int knobX = state ? sx + switchWidth - knobSize - 1 : sx + 1;
        ctx.fill(knobX, sy + 1, knobX + knobSize, sy + knobSize + 1, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && isHovered(mouseX, mouseY)) {
            setter.accept(!getter.getAsBoolean());
            return true;
        }
        return false;
    }
}
