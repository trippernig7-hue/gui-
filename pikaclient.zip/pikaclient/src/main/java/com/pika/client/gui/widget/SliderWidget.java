package com.pika.client.gui.widget;

import net.minecraft.client.gui.DrawContext;

import java.util.function.DoubleSupplier;
import java.util.function.DoubleConsumer;

/** A draggable slider for a double range, with a formatter for the display text. */
public class SliderWidget extends PikaWidget {

    private final double min, max;
    private final DoubleSupplier getter;
    private final DoubleConsumer setter;
    private final java.util.function.DoubleFunction<String> formatter;
    private boolean dragging = false;

    public SliderWidget(String label, int panelWidth, double min, double max,
                         DoubleSupplier getter, DoubleConsumer setter,
                         java.util.function.DoubleFunction<String> formatter) {
        super(label, panelWidth, 32);
        this.min = min;
        this.max = max;
        this.getter = getter;
        this.setter = setter;
        this.formatter = formatter;
    }

    private double trackX() { return x + 4; }
    private double trackWidth() { return width - 8; }

    private double valueToPixel(double value) {
        double pct = (value - min) / (max - min);
        return trackX() + pct * trackWidth();
    }

    private double pixelToValue(double px) {
        double pct = (px - trackX()) / trackWidth();
        pct = Math.max(0, Math.min(1, pct));
        return min + pct * (max - min);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, int accentColor) {
        double value = getter.getAsDouble();
        var tr = net.minecraft.client.MinecraftClient.getInstance().textRenderer;
        ctx.drawTextWithShadow(tr, label, x + 4, y + 2, 0xFFEAEAEA);
        String valText = formatter.apply(value);
        ctx.drawTextWithShadow(tr, valText, x + width - tr.getWidth(valText) - 4, y + 2, 0xFFB0B0B0);

        int trackY = y + 20;
        ctx.fill((int) trackX(), trackY, (int) (trackX() + trackWidth()), trackY + 3, 0xFF3A3A3A);
        int filledEnd = (int) valueToPixel(value);
        ctx.fill((int) trackX(), trackY, filledEnd, trackY + 3, accentColor);

        int knobX = (int) valueToPixel(value);
        ctx.fill(knobX - 3, trackY - 4, knobX + 3, trackY + 7, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && isHovered(mouseX, mouseY)) {
            dragging = true;
            setter.accept(pixelToValue(mouseX));
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging) {
            setter.accept(pixelToValue(mouseX));
            return true;
        }
        return false;
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
    }
}
