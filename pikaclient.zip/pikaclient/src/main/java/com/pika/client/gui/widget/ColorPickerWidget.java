package com.pika.client.gui.widget;

import net.minecraft.client.gui.DrawContext;

import java.util.function.IntSupplier;
import java.util.function.IntConsumer;

/** A horizontal hue-strip color picker. Click anywhere on the strip to pick that hue. */
public class ColorPickerWidget extends PikaWidget {

    private final IntSupplier getter;
    private final IntConsumer setter;

    public ColorPickerWidget(String label, int panelWidth, IntSupplier getter, IntConsumer setter) {
        super(label, panelWidth, 30);
        this.getter = getter;
        this.setter = setter;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, int accentColor) {
        var tr = net.minecraft.client.MinecraftClient.getInstance().textRenderer;
        ctx.drawTextWithShadow(tr, label, x + 4, y, 0xFFEAEAEA);

        int stripY = y + 12, stripH = 14;
        int stripX = x + 4, stripW = width - 8;
        int segments = 24;
        for (int i = 0; i < segments; i++) {
            float hue = i / (float) segments;
            int c = java.awt.Color.HSBtoRGB(hue, 0.9f, 1.0f);
            int sx1 = stripX + (stripW * i) / segments;
            int sx2 = stripX + (stripW * (i + 1)) / segments;
            ctx.fill(sx1, stripY, sx2, stripY + stripH, 0xFF000000 | (c & 0xFFFFFF));
        }

        // marker for current color's approximate hue position
        int current = getter.getAsInt();
        float[] hsb = java.awt.Color.RGBtoHSB(
                (current >> 16) & 0xFF, (current >> 8) & 0xFF, current & 0xFF, null);
        int markerX = stripX + (int) (hsb[0] * stripW);
        ctx.fill(markerX - 1, stripY - 2, markerX + 1, stripY + stripH + 2, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return tryPick(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return tryPick(mouseX, mouseY, button);
    }

    private boolean tryPick(double mouseX, double mouseY, int button) {
        int stripY = y + 12, stripH = 14;
        int stripX = x + 4, stripW = width - 8;
        if (button == 0 && mouseX >= stripX && mouseX <= stripX + stripW
                && mouseY >= stripY && mouseY <= stripY + stripH) {
            float hue = (float) ((mouseX - stripX) / stripW);
            int rgb = java.awt.Color.HSBtoRGB(hue, 0.9f, 1.0f) & 0xFFFFFF;
            setter.accept(rgb);
            return true;
        }
        return false;
    }
}
